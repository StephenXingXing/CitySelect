//
//  MyTableViewCell.m
//  城市选择demo2
//
//  Created by xzx on 2018/5/2.
//  Copyright © 2018年 xzx. All rights reserved.
//

#import "MyTableViewCell.h"

@implementation MyTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.backgroundColor=[UIColor clearColor];
    self.areaLab.backgroundColor=[UIColor clearColor];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
