//
//  CitySelectTableView.h
//  CitySelectTableView
//
//  Created by xzx on 2018/5/4.
//  Copyright © 2018年 xzx. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CitySelectTableView;
@protocol CitySelectTableViewDelegate <NSObject>
@optional
-(void)actionsheetDisappear:(CitySelectTableView *)actionSheet andAreaInfoDict:(NSDictionary *)dict;
@end

@interface CitySelectTableView : UIView
@property(nonatomic,weak) id<CitySelectTableViewDelegate> delegate;
-(void)show;
@end
