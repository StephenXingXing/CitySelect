//
//  MyTableViewCell.h
//  城市选择demo2
//
//  Created by xzx on 2018/5/2.
//  Copyright © 2018年 xzx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *areaLab;

@end
