//
//  CitySelectTableView.m
//  CitySelectTableView
//
//  Created by xzx on 2018/5/4.
//  Copyright © 2018年 xzx. All rights reserved.
//

#import "CitySelectTableView.h"
#import "MyTableViewCell.h"//cell

//定义两个宏，获取屏幕的宽高
#define Screen_Width [UIScreen mainScreen].bounds.size.width
#define Screen_Height [UIScreen mainScreen].bounds.size.height
//rgb颜色转换（16进制->10进制）
#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
#define kColorBlue                  UIColorFromRGB(0x25a5fe)//蓝色(主题色)
#define kColorBlack                 UIColorFromRGB(0x333333)//黑色
#define kColorWhite                 UIColorFromRGB(0xFFFFFF)//白色

@interface CitySelectTableView()<UITableViewDelegate,UITableViewDataSource>
{
    UITableView *_ProvinceTableView;//省
    UITableView *_CityTableView;//市
    UITableView *_CountryTableView;//县
}
@property (nonatomic, strong) UIButton *backView;//底层蒙版
@property (nonatomic, strong) NSDictionary *pickerDic;//接收总的Json数据源
@property (nonatomic, strong) NSArray *provinceList;//省的数组
@property (strong,nonatomic) NSArray *cityList;//市的数组
@property (strong,nonatomic) NSArray *areaList;//县和区的数组
@property (assign, nonatomic)NSInteger selectOneRow;//记录第一级选中的下标
@property (assign, nonatomic)NSInteger selectTwoRow;//记录第二级选中的下标
@property (assign, nonatomic)NSInteger selectThreeRow;//记录第三级选中的下标
@property (nonatomic, strong) NSDictionary *areaInfoDict;//最终通过代理回调出去的地区信息
@end

@implementation CitySelectTableView

/*****实现原理是现将window和背景蒙板backView先定下来，然后再动画弹出view，也就是说backView没有放在view上面，而是放在了window上面*****/

//初始化
-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    
    if(self){
        CGRect tmpframe = CGRectMake(0, Screen_Height, frame.size.width, frame.size.height);
        self.frame = tmpframe;//初次设置view的frame，到不可见的区域
        self.backgroundColor = kColorWhite;
        
        
        NSArray *windows = [UIApplication sharedApplication].windows;
        UIWindow *mainWin = windows[0];
        UIWindow *window = mainWin;
        for (NSInteger  i = windows.count-1; i >= 0; i--) {
            UIWindow *win = windows[i];
            if (CGRectEqualToRect(win.bounds, mainWin.bounds) && win.windowLevel == UIWindowLevelNormal) {
                window = win;
                break;
            }
        }
        
        
        _backView  = [UIButton buttonWithType:UIButtonTypeCustom];
        _backView.backgroundColor = kColorBlack;
        _backView.frame = CGRectMake(0, 64, Screen_Width, Screen_Height-64);//设置背景蒙板backView的frame是覆盖主屏幕的大小
        _backView.alpha = 0;
        [_backView addTarget:self action:@selector(hiddenActionSheet) forControlEvents:UIControlEventTouchUpInside];
        
        
        [window addSubview:_backView];//将背景蒙板backView放在window上
        [window addSubview:self];//将view放在window上
        
        [self createTableView];//创建tableView
    }
    return self;
}

//弹出view
-(void)show{
    CGRect frame = CGRectMake(0, 64, self.frame.size.width, self.frame.size.height);
    self.frame = frame;
    self.backView.alpha = 0.4;
}

//隐藏view,并销毁view及backView
-(void)hiddenActionSheet{
    CGRect frame = CGRectMake(0, Screen_Height, self.frame.size.width, self.frame.size.height);
    self.frame = frame;
    self.backView.alpha = 0;
    
    [self removeFromSuperview];
    [self.backView removeFromSuperview];
}

//创建tableView
-(void)createTableView{
    _areaInfoDict=[[NSDictionary alloc]init];
    
    CGRect frame = self.frame;
    frame.size.height = 400;
    self.frame = frame;//再次根据需要设置view的frame，高度为400，此时仍在不可见区域
    
    _ProvinceTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, Screen_Width/3,400) style:UITableViewStylePlain];
    _ProvinceTableView.delegate=self;
    _ProvinceTableView.dataSource=self;
    _ProvinceTableView.separatorInset=UIEdgeInsetsMake(0, 0, 0, 0);
    _ProvinceTableView.showsVerticalScrollIndicator=NO;
    _ProvinceTableView.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    [self addSubview:_ProvinceTableView];
    [_ProvinceTableView registerNib:[UINib nibWithNibName:@"MyTableViewCell" bundle:nil] forCellReuseIdentifier:@"cell1"];
    
    
    _CityTableView=[[UITableView alloc]initWithFrame:CGRectMake(Screen_Width/3, 0, Screen_Width/3,400) style:UITableViewStylePlain];
    _CityTableView.delegate=self;
    _CityTableView.dataSource=self;
    _CityTableView.separatorInset=UIEdgeInsetsMake(0, 0, 0, 0);
    _CityTableView.showsVerticalScrollIndicator=NO;
    _CityTableView.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    [self addSubview:_CityTableView];
    //注册集合视图cell
    [_CityTableView registerNib:[UINib nibWithNibName:@"MyTableViewCell" bundle:nil] forCellReuseIdentifier:@"cell2"];
    
    
    _CountryTableView=[[UITableView alloc]initWithFrame:CGRectMake(Screen_Width/3*2 ,0, Screen_Width/3,400) style:UITableViewStylePlain];
    _CountryTableView.delegate=self;
    _CountryTableView.dataSource=self;
    _CountryTableView.separatorInset=UIEdgeInsetsMake(0, 0, 0, 0);
    _CountryTableView.showsVerticalScrollIndicator=NO;
    _CountryTableView.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    [self addSubview:_CountryTableView];
    //注册集合视图cell
    [_CountryTableView registerNib:[UINib nibWithNibName:@"MyTableViewCell" bundle:nil] forCellReuseIdentifier:@"cell3"];
    
    [self Dataparsing];//解析json数据，获得省的数据
    [self getCitydate:0];//获得默认市的数据
    [self getAreaDate:0];//获得默认县区的数据
    [_ProvinceTableView reloadData];
    [_CityTableView reloadData];
    [_CountryTableView reloadData];
    //默认选中第一个数据
    [_ProvinceTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionTop];
    [_CityTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionTop];
    [_CountryTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionTop];
}


#pragma mark 解析json数据,获取省的数据
- (void)Dataparsing{
    self.provinceList = [[NSArray alloc]init];
    
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:@"city" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSError *error;
    NSDictionary *provinceLise = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
    self.pickerDic = provinceLise;
    self.provinceList = self.pickerDic[@"region"];
}

#pragma mark 取到市的数据，默认第0行
- (void)getCitydate:(NSInteger)row{
    self.cityList=[[NSArray alloc]init];
    
    NSMutableArray *cityList = [[NSMutableArray alloc] init];
    
    for (NSDictionary *dict in self.provinceList[row][@"children"]) {
        [cityList addObject:dict];
    }
    
    self.cityList = cityList;
}

#pragma mark 取到县区的数据，默认第0行
- (void)getAreaDate:(NSInteger)row{
    self.areaList=[[NSArray alloc]init];
    
    NSMutableArray *areaList = [[NSMutableArray alloc] init];
    
    for (NSDictionary *dict in self.cityList[row][@"children"]) {
        [areaList addObject:dict];
    }
    
    self.areaList = areaList;
    
    //对最终要回调出去的地区信息进行默认赋值（主要是针对首次启动没有触发pickerView滚动而言的，此时就塞进去首个信息，下标传0即可，一旦触发pickerView滚动了，就会走pickerView的代理方法，覆盖本次的赋值）
    _areaInfoDict=self.areaList[0];
}

#pragma mark tableView代理方法
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView==_ProvinceTableView) {//省
        return self.provinceList.count;
    }
    else if(tableView==_CityTableView){//市
        return self.cityList.count;
    }
    else{//县
        return self.areaList.count;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView==_ProvinceTableView) {//省
        MyTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell1"];
        
        cell.areaLab.text = self.provinceList[indexPath.row][@"name"];
        
        return cell;
    }
    else if(tableView==_CityTableView){//市
        MyTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell2"];
        
        cell.areaLab.text = self.cityList[indexPath.row][@"name"];
        
        return cell;
    }
    else{//县区
        MyTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell3"];
        
        cell.areaLab.text = self.areaList[indexPath.row][@"name"];
        
        return cell;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 35;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSInteger oneRow = 0;
    static NSInteger tweRow = 0;
    static NSInteger threeRow = 0;
    
    //省的那一栏
    if (tableView == _ProvinceTableView) {
        self.selectOneRow = indexPath.row;
        
        [self getCitydate:indexPath.row];
        [_CityTableView reloadData];//重新加载 第二列
        [_CityTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionTop];//默认选中第二列中的第一个数据
        
        [self getAreaDate:0];
        [_CountryTableView reloadData];//重新加载 第三列
        [_CountryTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionTop];//默认选中第三列中的第一个数据
        
        oneRow = indexPath.row;
        tweRow = 0;
        threeRow = 0;
    }
    
    //市的那一栏
    if (tableView == _CityTableView){
        self.selectTwoRow = indexPath.row;
        
        [self getAreaDate:indexPath.row];
        [_CountryTableView reloadData];//重新加载 第三列
        [_CountryTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionTop];//默认选中第三列中的第一个数据
        
        tweRow = indexPath.row;
        threeRow = 0;
    }
    
    //县区的那一栏
    if (tableView == _CountryTableView){
        self.selectThreeRow = indexPath.row;
        threeRow = indexPath.row;
        
        //对最终要回调出去的地区信息进行赋值
        if (threeRow != 0){//此时县区这一列是有选择滚动过
            _areaInfoDict=self.areaList[self.selectThreeRow];
        }
        else{//此时县区这一列没动过，那么就默认首个，下标0
            _areaInfoDict=self.areaList[0];
        }
        
        //将选中的地区信息回调出去
        if([_delegate respondsToSelector:@selector(actionsheetDisappear: andAreaInfoDict:)]){
            [_delegate actionsheetDisappear:self andAreaInfoDict:_areaInfoDict];
        }
        [self hiddenActionSheet];
    }
}



@end
