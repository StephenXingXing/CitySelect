//
//  ViewController.m
//  CitySelectPickerView
//
//  Created by xzx on 2018/5/4.
//  Copyright © 2018年 xzx. All rights reserved.
//

#import "ViewController.h"
#import "CitySelectPickerView.h"

//定义两个宏，获取屏幕的宽高
#define Screen_Width [UIScreen mainScreen].bounds.size.width
#define Screen_Height [UIScreen mainScreen].bounds.size.height

@interface ViewController ()<CitySelectPickerViewDelegate>

@property (nonatomic,strong) CitySelectPickerView *citySelectPickerView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title=@"城市选择demo";
    _citySelectPickerView=[[CitySelectPickerView alloc]initWithFrame:CGRectMake(0, 0, Screen_Width, Screen_Height)];
    _citySelectPickerView.delegate=self;
    [_citySelectPickerView show];
}


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //注意，一旦_citySelectPickerView消失了就释放掉了，触摸屏幕想再次show的时候必须重新alloc。
    _citySelectPickerView=[[CitySelectPickerView alloc]initWithFrame:CGRectMake(0, 0, Screen_Width, Screen_Height)];
    _citySelectPickerView.delegate=self;
    [_citySelectPickerView show];
}

#pragma mark CitySelectPickerView代理回调
-(void)actionsheetDisappear:(CitySelectPickerView *)actionSheet andAreaInfoDict:(NSDictionary *)dict{
    NSLog(@"我选中的地区信息是：%@",dict);
}



@end
