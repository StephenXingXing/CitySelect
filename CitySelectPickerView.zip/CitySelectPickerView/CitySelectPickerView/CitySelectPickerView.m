//
//  CitySelectPickerView.m
//  CitySelectPickerView
//
//  Created by xzx on 2018/5/4.
//  Copyright © 2018年 xzx. All rights reserved.
//

#import "CitySelectPickerView.h"

//定义两个宏，获取屏幕的宽高
#define Screen_Width [UIScreen mainScreen].bounds.size.width
#define Screen_Height [UIScreen mainScreen].bounds.size.height
//rgb颜色转换（16进制->10进制）
#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
#define kColorBlue                  UIColorFromRGB(0x25a5fe)//蓝色(主题色)
#define kColorBlack                 UIColorFromRGB(0x333333)//黑色
#define kColorWhite                 UIColorFromRGB(0xFFFFFF)//白色

@interface CitySelectPickerView()<UIPickerViewDelegate,UIPickerViewDataSource>
@property (nonatomic, strong) UIButton *backView;//底层蒙版
@property (nonatomic, strong) NSDictionary *pickerDic;//接收总的Json数据源
@property (nonatomic, strong) NSArray *provinceList;//省的数组
@property (strong,nonatomic) NSArray *cityList;//市的数组
@property (strong,nonatomic) NSArray *areaList;//县和区的数组
@property (assign, nonatomic)NSInteger selectOneRow;//记录第一级选中的下标
@property (assign, nonatomic)NSInteger selectTwoRow;//记录第二级选中的下标
@property (assign, nonatomic)NSInteger selectThreeRow;//记录第三级选中的下标
@property (nonatomic, strong) NSDictionary *areaInfoDict;//最终通过代理回调出去的地区信息
@end

@implementation CitySelectPickerView

/*****实现原理是现将window和背景蒙板backView先定下来，然后再动画弹出view，也就是说backView没有放在view上面，而是放在了window上面*****/

//初始化
-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    
    if(self){
        CGRect tmpframe = CGRectMake(0, Screen_Height, frame.size.width, frame.size.height);
        self.frame = tmpframe;//初次设置view的frame，到不可见的区域
        self.backgroundColor = kColorWhite;
        
        
        NSArray *windows = [UIApplication sharedApplication].windows;
        UIWindow *mainWin = windows[0];
        UIWindow *window = mainWin;
        for (NSInteger  i = windows.count-1; i >= 0; i--) {
            UIWindow *win = windows[i];
            if (CGRectEqualToRect(win.bounds, mainWin.bounds) && win.windowLevel == UIWindowLevelNormal) {
                window = win;
                break;
            }
        }
        
        
        _backView  = [UIButton buttonWithType:UIButtonTypeCustom];
        _backView.backgroundColor = kColorBlack;
        _backView.frame = CGRectMake(0, 0, Screen_Width, Screen_Height);//设置背景蒙板backView的frame是覆盖主屏幕的大小
        _backView.alpha = 0;
        [_backView addTarget:self action:@selector(hiddenActionSheet) forControlEvents:UIControlEventTouchUpInside];
        
        
        [window addSubview:_backView];//将背景蒙板backView放在window上
        [window addSubview:self];//将view放在window上
        
        [self createPickerView];//创建pickerView
    }
    return self;
}

//弹出view
-(void)show{
    __weak __typeof(self) weakSelf=self;
    //设置view的frame到可见区域（动画效果）
    [UIView animateWithDuration:0.4 animations:^{
        CGRect frame = CGRectMake(0, Screen_Height-weakSelf.frame.size.height, weakSelf.frame.size.width, weakSelf.frame.size.height);
        weakSelf.frame = frame;
        weakSelf.backView.alpha = 0.4;
    }];
}

//隐藏view,并销毁view及backView
-(void)hiddenActionSheet{
    __weak __typeof(self) weakSelf=self;
    //设置view的frame到不可见区域并从window上移除（动画效果）
    [UIView animateWithDuration:0.4 animations:^{
        CGRect frame = CGRectMake(0, Screen_Height, weakSelf.frame.size.width, weakSelf.frame.size.height);
        weakSelf.frame = frame;
        weakSelf.backView.alpha = 0;
    } completion:^(BOOL finished) {
        [weakSelf removeFromSuperview];
        [weakSelf.backView removeFromSuperview];
    }];
}

//创建pickerView
-(void)createPickerView{
    _areaInfoDict=[[NSDictionary alloc]init];
    
    CGRect frame = self.frame;
    frame.size.height = 300;
    self.frame = frame;//再次根据需要设置view的frame，高度为300，此时仍在不可见区域
    
    //背景View
    UIView *bgview = [[UIView alloc]init];
    bgview.frame = CGRectMake(0, 0, self.frame.size.width, 300);
    [self addSubview:bgview];
    
    //放取消和确定按钮
    UIView *btnView = [[UIView alloc]init];
    btnView.frame = CGRectMake(0, 0, self.frame.size.width, 40);
    btnView.backgroundColor = kColorBlue;
    [bgview addSubview:btnView];
    
    UIButton *sureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    sureBtn.frame = CGRectMake(10, 5, 60, 30);
    [sureBtn setTitle:@"取消" forState:UIControlStateNormal];
    [sureBtn setTitleColor:kColorBlack forState:UIControlStateNormal];
    [sureBtn addTarget:self action:@selector(sureBtn) forControlEvents:UIControlEventTouchUpInside];
    [btnView addSubview:sureBtn];
    
    UIButton *cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    cancelBtn.frame = CGRectMake(self.frame.size.width - 70, 5, 60, 30);
    [cancelBtn setTitle:@"确定" forState:UIControlStateNormal];
    [cancelBtn setTitleColor:kColorBlack forState:UIControlStateNormal];
    [cancelBtn addTarget:self action:@selector(cancelBtn) forControlEvents:UIControlEventTouchUpInside];
    [btnView addSubview:cancelBtn];
    
    //创建选择器
    UIPickerView *pickerview = [[UIPickerView alloc]init];
    pickerview.frame = CGRectMake(0, 40, self.frame.size.width, 260);
    pickerview.delegate = self;
    pickerview.dataSource = self;
    pickerview.backgroundColor=kColorWhite;
    [bgview addSubview:pickerview];
    
    [self Dataparsing];//解析json数据，获得省的数据
    [self getCitydate:0];//获得默认市的数据
    [self getAreaDate:0];//获得默认县区的数据
    [pickerview reloadAllComponents];
}

//点击确定
- (void)sureBtn{
    [self hiddenActionSheet];
}

//点击取消，将选中的地区信息回调出去
- (void)cancelBtn{
    if([_delegate respondsToSelector:@selector(actionsheetDisappear: andAreaInfoDict:)]){
        [_delegate actionsheetDisappear:self andAreaInfoDict:_areaInfoDict];
    }
    [self hiddenActionSheet];
}

#pragma mark 解析json数据,获取省的数据
- (void)Dataparsing{
    self.provinceList = [[NSArray alloc]init];
    
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:@"city" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSError *error;
    NSDictionary *provinceLise = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
    self.pickerDic = provinceLise;
    self.provinceList = self.pickerDic[@"region"];
}

#pragma mark 取到市的数据，默认第0行
- (void)getCitydate:(NSInteger)row{
    self.cityList=[[NSArray alloc]init];
    
    NSMutableArray *cityList = [[NSMutableArray alloc] init];
    
    for (NSDictionary *dict in self.provinceList[row][@"children"]) {
        [cityList addObject:dict];
    }
    
    self.cityList = cityList;
}

#pragma mark 取到县区的数据，默认第0行
- (void)getAreaDate:(NSInteger)row{
    self.areaList=[[NSArray alloc]init];
    
    NSMutableArray *areaList = [[NSMutableArray alloc] init];
    
    for (NSDictionary *dict in self.cityList[row][@"children"]) {
        [areaList addObject:dict];
    }
    
    self.areaList = areaList;
    
    //对最终要回调出去的地区信息进行默认赋值（主要是针对首次启动没有触发pickerView滚动而言的，此时就塞进去首个信息，下标传0即可，一旦触发pickerView滚动了，就会走pickerView的代理方法，覆盖本次的赋值）
    _areaInfoDict=self.areaList[0];
}

#pragma mark pickerView代理方法
//返回列数
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 3;
}

//返回每列行数
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if (component == 0) {//省的行数
        return self.provinceList.count;
    }
    else if (component == 1){//市的行数
        return self.cityList.count;
    }
    else{//县区的行数
        return self.areaList.count;
    }
    return 0;
}

//返回每列每行的标题
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if (component == 0) {//省的标题
        return self.provinceList[row][@"name"];
    }
    if (component == 1){//市的标题
        return self.cityList[row][@"name"];
    }
    if (component == 2){//县区的标题
        return self.areaList[row][@"name"];
    }
    return nil;
}

//返回行高
- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component{
    return 25;
}

//当选中每列每行的事件
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    //注意此处一定要用static
    static NSInteger oneRow = 0;
    static NSInteger tweRow = 0;
    static NSInteger threeRow = 0;
    
    //省的那一列
    if (component == 0) {
        self.selectOneRow = row;
        
        [self getCitydate:row];//取到对应的市的数据
        [pickerView reloadComponent:1];//重新加载 第二列
        [pickerView selectRow:0 inComponent:1 animated:YES];//默认选中第二列中的第一个数据
        
        [self getAreaDate:0];//取到对应的县区的数据
        [pickerView reloadComponent:2];//重新加载第三列
        [pickerView selectRow:0 inComponent:2 animated:YES];//默认选中第三列中的第一个数据
        
        oneRow = row;
        tweRow = 0;
        threeRow = 0;
    }
    
    //市的那一列
    if (component == 1){
        self.selectTwoRow = row;
        
        [self getAreaDate:row];//取到对应的县区的数据
        [pickerView reloadComponent:2];//重新加载第三列
        [pickerView selectRow:0 inComponent:2 animated:YES];//默认选中第三列中的第一个数据
        
        tweRow = row;
        threeRow = 0;
    }
    
    //县区的那一列
    if (component == 2){
        self.selectThreeRow = row;
        threeRow = row;
        
        //对最终要回调出去的地区信息进行赋值
        if (threeRow != 0){//此时县区这一列是有选择滚动过
            _areaInfoDict=self.areaList[self.selectThreeRow];
        }
        else{//此时县区这一列没动过，那么就默认首个，下标0
            _areaInfoDict=self.areaList[0];
        }
    }
}



@end



