//
//  CitySelectPickerView.h
//  CitySelectPickerView
//
//  Created by xzx on 2018/5/4.
//  Copyright © 2018年 xzx. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CitySelectPickerView;
@protocol CitySelectPickerViewDelegate <NSObject>
@optional
-(void)actionsheetDisappear:(CitySelectPickerView *)actionSheet andAreaInfoDict:(NSDictionary *)dict;
@end


@interface CitySelectPickerView : UIView
@property(nonatomic,weak) id<CitySelectPickerViewDelegate> delegate;
-(void)show;
@end
